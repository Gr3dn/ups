package com.blackjack.net;

import com.blackjack.MainApp.LobbyRow;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class NetClient {
    private final Socket socket;
    private final OutputStream os;
    private final BufferedReader br;
    private Thread reader;

    private NetClient(Socket s) throws IOException {
        this.socket = s;
        this.os = s.getOutputStream();
        this.br = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
    }

    public static NetClient connect(String host, int port, int timeoutMs) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, port), timeoutMs);
        s.setSoTimeout(30000);
        return new NetClient(s);
    }

    public void startReader(ProtocolListener l) {
        reader = new Thread(() -> {
            try {
                boolean okSeen = false;
                while (true) {
                    String line = br.readLine();
                    if (line == null) throw new EOFException("server closed");
                    String t = line.trim();
                    if (t.isEmpty()) continue;

                    // базовые токены
                    if (t.startsWith("C45OK")) {
                        if (!okSeen) { okSeen = true; l.onOk(); }
                        else { l.onLobbyJoinOk(); }
                        continue;
                    }
                    if(t.startsWith("C45WRONG NAME_TAKEN")){
                        l.onServerError("Name has been taken");
                        break;
                    }
                    if (t.startsWith("C45WRONG") || t.startsWith("WRONG")) {
                        l.onServerError("WRONG");
                        continue;
                    }

                    // снимок лобби: "C45LOBBIES N" + N строк "C45LOBBY ..."
                    if (t.startsWith("C45LOBBIES")) {
                        String[] p = t.split("\\s+");
                        int n = (p.length >= 2) ? Integer.parseInt(p[1]) : Integer.parseInt(br.readLine().trim());
                        List<LobbyRow> rows = new ArrayList<>();
                        for (int i = 0; i < n; i++) rows.add(parseLobbyLine(br.readLine().trim()));
                        l.onLobbySnapshot(rows);
                        continue;
                    }

                    // игровая часть
                    if (t.startsWith("C45DEAL")) {
                        String[] p = t.split("\\s+");
                        if (p.length >= 3) l.onDeal(p[1], p[2]);
                        continue;
                    }
                    if (t.startsWith("C45TURN")) {
                        String[] p = t.split("\\s+");
                        String who = (p.length >= 2) ? p[1] : "?";
                        int sec = (p.length >= 3) ? Integer.parseInt(p[2]) : 30;
                        l.onTurn(who, sec); continue;
                    }
                    if (t.startsWith("C45CARD")) {
                        String[] p = t.split("\\s+");
                        if (p.length >= 2) l.onCard(p[1]); continue;
                    }
                    if (t.startsWith("C45BUST")) {
                        String[] p = t.split("\\s+");
                        if (p.length >= 3) l.onBust(p[1], Integer.parseInt(p[2])); continue;
                    }
                    if (t.startsWith("C45RESULT")) {
                        l.onResult(t); continue;
                    }
                    if (t.startsWith("C45WAITING")) {
                        try {
                            sendYes();
//                            l.onWaitingPing();
                        } catch (IOException ioe) {
                            l.onServerError("send C45YES failed: " + ioe.getMessage());
                        }
                        continue;
                    }
                }
            } catch (Exception ex) {
                System.out.println(ex);
                System.out.println("Trying read Bad line");
                l.onServerError(ex.getMessage());
            }
        }, "net-reader");
        reader.setDaemon(true);
        reader.start();
    }

    // отправка команд
    public synchronized void sendRaw(String s) throws IOException { os.write(s.getBytes(StandardCharsets.UTF_8)); os.flush(); }
    public void sendName(String name) throws IOException { sendRaw("C45" + name + "\n"); }
    // Совместимо с твоим текущим форматом "C45<name><lobby>"
    public void sendJoin(String name, int lobby) throws IOException { sendRaw("C45" + name + lobby + "\n"); }
    // Если перейдёшь на явную команду: sendRaw("C45JOIN " + lobby + "\n");
    public void sendHit() throws IOException { sendRaw("C45HIT\n"); }
    public void sendStand() throws IOException { sendRaw("C45STAND\n"); }
    public void sendYes() throws IOException { sendRaw("C45YES\n"); }

    public void closeQuietly() {
        try { br.close(); } catch (Exception ignored) {}
        try { os.close(); } catch (Exception ignored) {}
        try { socket.close(); } catch (Exception ignored) {}
    }



    // перенос парсера строки лобби из MainApp
    private LobbyRow parseLobbyLine(String line) throws IOException {
        String[] parts = line.split("\\s+");
        if (parts.length != 4 || !parts[0].equalsIgnoreCase("C45LOBBY"))
            throw new IOException("Bad lobby line: " + line);
        int id = Integer.parseInt(parts[1]);
        String[] ps = parts[2].split("=")[1].split("/");
        int players = Integer.parseInt(ps[0]);
        int cap = Integer.parseInt(ps[1]);
        String status = parts[3].split("=")[1];
        return new LobbyRow(id, players, cap, status);
    }
}
