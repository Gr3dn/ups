package com.blackjack;

import com.blackjack.net.NetClient;
import com.blackjack.net.ProtocolListener;
import com.blackjack.ui.GameView;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.EOFException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainApp extends Application {

    // -------- Нетворк / состояние --------
    private NetClient client;
    private String name;
    private int lastLobbySelected = -1;

    // -------- UI --------
    private Stage primaryStage;
    private GameView gameView; // создаём при входе в лобби

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        stage.setTitle("Blackjack Client — подключение");
        stage.setScene(buildConnectScene(null));
        stage.show();
    }

    // ---------- Модель строки лобби (используется NetClient) ----------
    public static class LobbyRow {
        private final IntegerProperty id = new SimpleIntegerProperty();
        private final IntegerProperty players = new SimpleIntegerProperty();
        private final IntegerProperty capacity = new SimpleIntegerProperty();
        private final StringProperty status = new SimpleStringProperty();

        public LobbyRow(int id, int players, int capacity, String status) {
            this.id.set(id);
            this.players.set(players);
            this.capacity.set(capacity);
            this.status.set(status);
        }

        public int getId() { return id.get(); }
        public int getPlayers() { return players.get(); }
        public int getCapacity() { return capacity.get(); }
        public String getStatus() { return status.get(); }
    }

    // =================================================================
    //                                СЦЕНЫ
    // =================================================================

    // ---------- Подключение ----------
    private Scene buildConnectScene(String msg) {
        TextField ipField = new TextField();
        ipField.setPromptText("IP сервера (например, 127.0.0.1)");
        TextField portField = new TextField();
        portField.setPromptText("Порт сервера (например, 10000)");

        Button connectBtn = new Button("Подключиться");
        Label status = new Label(msg == null ? "" : msg);

        connectBtn.setOnAction(e -> {
            String ip = ipField.getText().trim();
            String portText = portField.getText().trim();
            if (ip.isEmpty() || portText.isEmpty()) { status.setText("Введите IP и порт."); return; }

            int port;
            try {
                port = Integer.parseInt(portText);
                if (port < 1 || port > 65535) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                status.setText("Порт должен быть числом 1–65535.");
                return;
            }

            connectBtn.setDisable(true);
            status.setText("Подключение...");

            new Thread(() -> {
                try {
                    closeClient();
                    client = NetClient.connect(ip, port, 30000);
                    Platform.runLater(() -> {
                        primaryStage.setTitle("Blackjack Client — введите имя");
                        primaryStage.setScene(buildNameScene());
                    });
                } catch (Exception ex2) {
                    String reason = normalizeNetError(ex2);
                    goToConnectScene("Ошибка подключения: " + reason);
                } finally {
                    Platform.runLater(() -> connectBtn.setDisable(false));
                }
            }, "connect-thread").start();
        });

        GridPane root = new GridPane();
        root.setPadding(new Insets(16));
        root.setVgap(10);
        root.setHgap(10);
        root.add(new Label("IP сервера:"), 0, 0);
        root.add(ipField, 1, 0);
        root.add(new Label("Порт:"), 0, 1);
        root.add(portField, 1, 1);
        root.add(connectBtn, 1, 2);
        root.add(status, 1, 3);
        GridPane.setColumnSpan(status, 2);
        root.setAlignment(Pos.CENTER);

        return new Scene(root, 460, 200);
    }

    // ---------- Ввод имени ----------
    private Scene buildNameScene() {
        TextField nameField = new TextField();
        nameField.setPromptText("Ваше имя");
        Button sendBtn = new Button("Отправить");
        Label status = new Label();

        sendBtn.setOnAction(e -> {
            name = nameField.getText().trim();
            if (name.isEmpty()) { status.setText("Имя не должно быть пустым."); return; }
            sendBtn.setDisable(true);
            status.setText("Отправка имени...");

            new Thread(() -> {
                try {
                    if (client == null) throw new SocketException("Разорвано соединение");
                    // запускаем ридер С ПОДПИСАННЫМ listener'ом
                    client.startReader(buildListener());
                    client.sendName(name);
                } catch (Exception ex) {
                    String reason = normalizeNetError(ex);
                    System.out.println("build Name");
                    goToConnectScene("Соединение потеряно: " + reason);
                } finally {
                    Platform.runLater(() -> sendBtn.setDisable(false));
                }
            }, "send-name-thread").start();
        });

        GridPane root = new GridPane();
        root.setPadding(new Insets(16));
        root.setVgap(10);
        root.setHgap(10);
        root.add(new Label("Имя:"), 0, 0);
        root.add(nameField, 1, 0);
        root.add(sendBtn, 1, 1);
        root.add(status, 1, 2);
        GridPane.setColumnSpan(status, 2);
        root.setAlignment(Pos.CENTER);

        return new Scene(root, 420, 160);
    }

    // ---------- Ожидание снимка лобби ----------
    private Scene buildLobbyWaitingScene() {
        Label lbl = new Label("Подтверждено. Ожидаем список лобби от сервера...");
        ProgressIndicator pi = new ProgressIndicator();
        pi.setPrefSize(48, 48);

        VBox mid = new VBox(12, lbl, pi);
        mid.setAlignment(Pos.CENTER);

        Button backBtn = new Button("Отключиться");
        backBtn.setOnAction(e -> {
            closeClient();
            goToConnectScene("Соединение закрыто.");
        });

        VBox root = new VBox(20, mid, backBtn);
        root.setPadding(new Insets(16));
        root.setAlignment(Pos.CENTER);

        return new Scene(root, 520, 260);
    }

    // ---------- Выбор лобби ----------
    private Scene buildLobbyChoiceScene(ObservableList<LobbyRow> rows) {
        VBox listBox = new VBox(8);
        listBox.setFillWidth(true);

        Label title = new Label("Доступные лобби:");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        for (LobbyRow r : rows) {
            String text = String.format(
                    "Лобби #%d — игроков: %d/%d — статус: %s",
                    r.getId(), r.getPlayers(), r.getCapacity(), r.getStatus()
            );
            Label item = new Label(text);
            item.setPadding(new Insets(8));
            item.setStyle("-fx-background-color: #f3f3f3; -fx-background-radius: 6;");
            listBox.getChildren().add(item);
        }

        TextField lobbyField = new TextField();
        lobbyField.setPromptText("Введите номер лобби (1–5)");

        Label status = new Label();
        Button joinBtn = new Button("Подключиться к лобби");

        joinBtn.setOnAction(e -> {
            String t = lobbyField.getText().trim();
            int num;
            try {
                num = Integer.parseInt(t);
                if (num < 1 || num > 5) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                status.setText("Введите число от 1 до 5.");
                return;
            }

            joinBtn.setDisable(true);
            status.setText("Отправка номера лобби...");

            lastLobbySelected = num;

            new Thread(() -> {
                try {
                    if (client == null) throw new SocketException("Разорвано соединение");
                    // Совместимо с текущим сервером: "C45" + name + lobbyNum + "\n"
                    client.sendJoin(Objects.requireNonNullElse(name, ""), num);
                    Platform.runLater(() -> status.setText("Отправлено: " + num));
                    // Подтверждение входа придёт как onLobbyJoinOk() из listener
                } catch (Exception ex2) {
                    String reason = normalizeNetError(ex2);
                    System.out.println("build Lobby Choice");
                    goToConnectScene("Соединение потеряно: " + reason);
                } finally {
                    Platform.runLater(() -> joinBtn.setDisable(false));
                }
            }, "send-lobby-thread").start();
        });

        Button backBtn = new Button("Отключиться");
        backBtn.setOnAction(e -> {
            closeClient();
            goToConnectScene("Соединение закрыто.");
        });

        VBox root = new VBox(12,
                title,
                listBox,
                new HBox(8, new Label("Номер лобби:"), lobbyField, joinBtn),
                status,
                backBtn
        );
        ((HBox)root.getChildren().get(2)).setAlignment(Pos.CENTER_LEFT);
        root.setPadding(new Insets(16));

        return new Scene(root, 560, 400);
    }

    // =================================================================
    //                          LISTENER ПРОТОКОЛА
    // =================================================================

    private ProtocolListener buildListener() {
        return new ProtocolListener() {
            @Override
            public void onOk() {
                Platform.runLater(() -> {
                    primaryStage.setTitle("Blackjack Client — Лобби (ожидание данных)");
                    primaryStage.setScene(buildLobbyWaitingScene());
                });
            }

            @Override
            public void onLobbySnapshot(List<LobbyRow> rows) {
                Platform.runLater(() -> {
                    ObservableList<LobbyRow> data = FXCollections.observableArrayList(new ArrayList<>(rows));
                    primaryStage.setTitle("Blackjack Client — Выбор лобби");
                    primaryStage.setScene(buildLobbyChoiceScene(data));
                });
            }

            @Override
            public void onLobbyJoinOk() {
                Platform.runLater(() -> {
                    int ln = lastLobbySelected > 0 ? lastLobbySelected : 0;
                    gameView = new GameView(ln);
                    gameView.bindClient(client);
                    primaryStage.setTitle("Blackjack Client — Игра");
                    primaryStage.setScene(gameView.scene());
                });
            }

            @Override
            public void onServerError(String msg) {
                String reason = (msg == null || msg.isBlank()) ? "Ошибка сервера" : msg;
                System.out.println(msg);
                Platform.runLater(() -> goToConnectScene("11Соединение потеряно: " + reason));
            }

//            @Override
//            public void onWaitingPing(){
//                primaryStage.setTitle("... ждём второго игрока ...");
//            }


            // ----- игровая фаза -----
            @Override public void onDeal(String c1, String c2) {
                if (gameView != null) Platform.runLater(() -> gameView.onDeal(c1, c2));
            }
            @Override public void onTurn(String player, int seconds) {
                if (gameView != null) Platform.runLater(() -> gameView.onTurn(player, seconds));
            }
            @Override public void onCard(String card) {
                if (gameView != null) Platform.runLater(() -> gameView.onCard(card));
            }
            @Override public void onBust(String player, int value) {
                if (gameView != null) Platform.runLater(() -> gameView.onBust(player, value));
            }
            @Override public void onResult(String summary) {
                if (gameView != null) Platform.runLater(() -> gameView.onResult(summary));
            }
        };
    }

    // =================================================================
    //                           УТИЛИТЫ/ЖИЗНЕННЫЙ ЦИКЛ
    // =================================================================

    private void goToConnectScene(String message) {
        closeClient();
        Platform.runLater(() -> {
            primaryStage.setTitle("Blackjack Client — подключение");
            primaryStage.setScene(buildConnectScene(message));
        });
    }

    private String normalizeNetError(Exception ex) {
        String s = ex.getMessage();
        if (s == null || s.isBlank()) s = ex.getClass().getSimpleName();
        if (ex instanceof EOFException) s = "Соединение закрыто сервером";
        return s;
    }

    private void closeClient() {
        try { if (client != null) client.closeQuietly(); } catch (Exception ignored) {}
        client = null;
        gameView = null;
        lastLobbySelected = -1;
    }

    @Override
    public void stop() {
        closeClient();
    }

    public static void main(String[] args) {
        Application.launch(MainApp.class, args);
    }
}
